import XCTest

class AvatarsTests: XCTestCase {

}
