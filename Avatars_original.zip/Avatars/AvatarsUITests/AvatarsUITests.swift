import XCTest

class AvatarsUITests: XCTestCase {

}
