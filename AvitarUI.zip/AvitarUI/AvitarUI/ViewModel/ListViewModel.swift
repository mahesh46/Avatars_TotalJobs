// ListViewModel.swift
//
// Copyright © 2023 Stepstone. All rights reserved.

import Foundation

@MainActor
class ListViewModel: ObservableObject {
    
    @Published  var gitUser: [GitUser] = []
    init(){}
    func getGitUser() async  -> [GitUser]? {
        do {
            let ArrayUser: [GitUser] = try await NetworkService.shared.get(url: .githubUsersEndpoint, resultType: [GitUser].self)
            gitUser = ArrayUser
            return gitUser
        } catch  {
            print(error.localizedDescription)
            return nil
        }
    }
}
