//
//  DetailViewModel.swift
//  AvitarUI
//
//  Created by mahesh lad on 01/07/2023.
//

import Foundation

class DetailViewModel: ObservableObject {
    
    @Published var detailLabels = [DetailList]()
    let dispatchGroup = DispatchGroup()
    init(){}
    
    func updateLabel(repoUrl: String, followersUrl: String, followingUrl:String, gistsUrl: String) async  -> Void {
        var detailArray = [String]()
        dispatchGroup.enter()
        do {
            let followers =  try await NetworkService.shared.get(url: followersUrl, resultType: [GitUser].self)
            detailArray.append("Followers: \(followers.count)")
            dispatchGroup.leave()
        } catch {
            detailArray.append("Followers: N/A")
            dispatchGroup.leave()
        }
        
        dispatchGroup.enter()
        do {
            let following =  try await NetworkService.shared.get(url: followingUrl, resultType: [GitUser].self)
            detailArray.append("Following: \(following.count)")
            dispatchGroup.leave()
        } catch {
            detailArray.append("Following: N/A")
            dispatchGroup.leave()
        }
        
        
        dispatchGroup.enter()
        do {
            let repos =  try await NetworkService.shared.get(url: repoUrl, resultType: [Repo].self)
            detailArray.append("Repositories count: \(repos.count)")
            dispatchGroup.leave()
        } catch {
            detailArray.append("Repositories count: N/A")
            dispatchGroup.leave()
        }
        
        dispatchGroup.enter()
        do {
            let repos =  try await NetworkService.shared.get(url: gistsUrl, resultType: [Gist].self)
            detailArray.append("Gists count: \(repos.count)")
            dispatchGroup.leave()
        } catch {
            detailArray.append("Gists count: N/A")
            dispatchGroup.leave()
        }
        
        dispatchGroup.notify(queue: .main) { [self] in
            // All network requests have completed
            detailArray.forEach { label in
                detailLabels.append(DetailList(id: UUID(), detailLabel: label))
            }
        }
    }
}
