//
//  ContentView.swift
//  AvitarUI
//
//  Created by mahesh lad on 01/07/2023.
//

import SwiftUI

struct ListView: View {
    
    @StateObject private var listViewModel = ListViewModel()
    
    var body: some View {
        NavigationStack {
            List(listViewModel.gitUser, id: \.id) { user in
                
                NavigationLink(user.login, value: user) {
                HStack {
                   
                    AsyncImage(url: URL(string:user.avatar_url)){ image in image.resizable() } placeholder: { Color.red } .frame(width: 50, height: 50) .clipShape(RoundedRectangle(cornerRadius: 25))
                        .imageScale(.large)
                        .foregroundColor(.accentColor)
                    VStack(alignment: .leading){
                        Text(user.login)
                            .font(.headline)
                        Text(user.url)
                            .font(.subheadline)
                    }
                }
                .padding()
               
                } //naigation
                
            }.listStyle(.plain)
            .task {
                _ = await listViewModel.getGitUser()
            }
            .navigationTitle("Avitar")
            .navigationDestination(for: GitUser.self) { user in
                            DetailView(user: user)
                        }
        }
       
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
