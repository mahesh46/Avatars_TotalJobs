
import Foundation
import Combine

enum NetworkError: Error {
    case noData
    case invalidURL
    case invalidImageData
    case urlError
}

class NetworkService {
    static let shared = NetworkService()
    private let session = URLSession.shared
    
}

// MARK: - Structured Concurrency

extension NetworkService {
    func get<Object: Codable>(
        url: String,
        resultType: Object.Type = Object.self
    ) async throws -> Object {
        let data = try await session.data(for: URLRequest(url: URL(string: url)!)).0
        
        return try JSONDecoder().decode(Object.self, from: data)
    }
    
    func get(url: String) async throws -> Data {
        try await session.data(for: URLRequest(url: URL(string: url)!)).0
    }
}

