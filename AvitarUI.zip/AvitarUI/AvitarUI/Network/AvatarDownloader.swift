
import UIKit
import Combine

class AvatarDownloader  : LoadAvitarProtocol {
    private enum Constants {
        static let endpoint = "https://i.pravatar.cc"
    }
    
    func downloadAvatar(avatarID: String, size: Int) async throws -> UIImage {
        var components = URLComponents(string: Constants.endpoint + "/" + "\(size)")
        components?.queryItems = [
            URLQueryItem(name: "img", value: avatarID)
        ]
        
        guard let imageUrl = components?.url else {
            throw NetworkError.invalidURL
        }
        
        let (data, _) = try await URLSession.shared.data(from: imageUrl)
        
        guard let image = UIImage(data: data) else {
            throw NetworkError.invalidImageData
        }
        
        return image
    }
}

protocol LoadAvitarProtocol {
    func downloadAvatar(avatarID: String, size: Int) async throws -> UIImage
}
