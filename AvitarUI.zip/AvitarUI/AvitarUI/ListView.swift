//
//  ContentView.swift
//  AvitarUI
//
//  Created by mahesh lad on 01/07/2023.
//

import SwiftUI

struct ListView: View {
    
    @StateObject private var listViewModel = ListViewModel()
    
    var body: some View {
        NavigationStack {
            List(listViewModel.gitUser, id: \.id) { user in
                NavigationLink(value: user) {
                    HStack {
                        AsyncImage(url: URL(string:user.avatar_url)){ image in image.resizable() } placeholder: { Color.white } .frame(width: 100, height: 100) .clipShape(RoundedRectangle(cornerRadius: 50))
                            .imageScale(.large)
                            .foregroundColor(.accentColor)
                            .accessibilityIdentifier("cellImage")
                        VStack(alignment: .leading){
                            Text("user.login")
                                .font(.headline)
                                .accessibilityIdentifier("cellLogInLabel")
                            Text("Github:\(user.html_url)")
                                .font(.subheadline)
                                .accessibilityIdentifier("cellGithubLabel")
                        }
                    }
                    .padding()
                    
                }
                
            }.listStyle(.automatic)
                .task {
                    _ = await listViewModel.getGitUser()
                }
                .navigationTitle("Avatar")
                .navigationBarTitleDisplayMode(.inline)
                .navigationDestination(for: GitUser.self) { user in
                    
                    let userDetail = UserDetail(name: user.login, html_url: user.html_url, avatar_url: user.avatar_url, repos_url: user.repos_url, followers_url: user.followers_url, following_url: user.following_url, gists_url: user.gists_url)
                    DetailView().environmentObject(userDetail)
                }
        }
        
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
