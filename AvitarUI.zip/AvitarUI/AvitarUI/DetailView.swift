//
//  DetailView.swift
//  AvitarUI
//
//  Created by mahesh lad on 01/07/2023.
//

import SwiftUI

struct DetailView: View {
    @EnvironmentObject  var user: UserDetail
    @StateObject private var detailViewModel = DetailViewModel()
    @State private var showActivity: Bool = false
    var body: some View {
        VStack {
            
                AsyncImage(url: URL(string:user.avatar_url)){ image in image.resizable() } placeholder: { Color.red } .frame(width: 150, height: 150) .clipShape(RoundedRectangle(cornerRadius: 75))
                    .imageScale(.large)
                    .foregroundColor(.accentColor)
                    .accessibilityIdentifier("userImage")
              
                    Text(user.name)
                        .font(.headline)
                        .accessibilityIdentifier("userLabel")
            Text("Githbb:\(user.html_url)")
                        .font(.subheadline)
                        .accessibilityIdentifier("githubGithubLabel")
              
                .padding(/*@START_MENU_TOKEN@*/.horizontal/*@END_MENU_TOKEN@*/)
            
            ProgressView()
                .opacity(showActivity ? 0 : 1)
        }  //.navigationBarTitle("")
           // .navigationBarHidden(true)
        
        VStack ( alignment: .leading, spacing: 20){
            List {
                ForEach(detailViewModel.detailLabels, id: \.id) { detail in
                    Text(detail.detailLabel)
                }
            }
            
        } .onAppear(){
            
            Task {
                
                await detailViewModel.updateLabel(repoUrl: user.repos_url, followersUrl:user.followers_url, followingUrl: user.following_url, gistsUrl: user.gists_url)
                showActivity.toggle()
            }
        }
        
        Spacer()
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
