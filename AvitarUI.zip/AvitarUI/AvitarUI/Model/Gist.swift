
import Foundation

struct Gist: Codable {
    let id: Int
    let user: String
    let url: String
}
