//
//  UserDetail.swift
//  AvitarUI
//
//  Created by mahesh lad on 01/07/2023.
//

import Foundation

class UserDetail: ObservableObject {
    @Published var name: String
    @Published var html_url: String
    @Published var avatar_url: String
    @Published var repos_url: String
    @Published var followers_url: String
    @Published var following_url: String
    @Published var gists_url: String
    
    init(name: String, html_url: String, avatar_url: String, repos_url: String, followers_url: String, following_url: String, gists_url: String  ) {
        self.name = name
        self.html_url = html_url
        self.avatar_url = avatar_url
        self.repos_url = repos_url
        self.followers_url = followers_url
        self.following_url = following_url
        self.gists_url =  gists_url
    }
}
