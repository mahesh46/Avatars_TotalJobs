//
//  DetailList.swift
//  AvitarUI
//
//  Created by mahesh lad on 02/07/2023.
//

import Foundation

struct DetailList: Codable {
    let id: UUID
    let detailLabel: String
}
