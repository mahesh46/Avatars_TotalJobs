//
//  AvitarUIApp.swift
//  AvitarUI
//
//  Created by mahesh lad on 01/07/2023.
//

import SwiftUI

@main
struct AvitarUIApp: App {
    var body: some Scene {
        WindowGroup {
            ListView()
        }
    }
}
