//
//  AvitarUIUITests.swift
//  AvitarUIUITests
//
//  Created by mahesh lad on 01/07/2023.
//

import XCTest
@testable import AvitarUI

final class AvitarUIUITests: XCTestCase {
    
    var  app: XCUIApplication!
    
    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    fileprivate func checkTableViewCell() {
        let cell = app.collectionViews.children(matching: .cell).element(boundBy: 0)
        let cellImage = cell.images["cellImage"]
        let cellLogInLabel = cell.staticTexts["cellLogInLabel"]
        let cellGithubLabel = cell.staticTexts["cellGithubLabel"]
        
        XCTAssert(cell.exists)
        XCTAssert(cellImage.exists)
        XCTAssert(cellLogInLabel.exists)
        XCTAssert(cellGithubLabel.exists)
    }
    
    fileprivate func pickFirstCell() {
       // let celUserName = app.staticTexts["mojombo"]
      //  celUserName.tap()
        
        let collectionViewsQuery = app.collectionViews
        collectionViewsQuery/*@START_MENU_TOKEN@*/.buttons["user.login, Github:https://github.com/mojombo"]/*[[".cells.buttons[\"user.login, Github:https:\/\/github.com\/mojombo\"]",".buttons[\"user.login, Github:https:\/\/github.com\/mojombo\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
    }
    
    fileprivate func checkNavigationBarButton() {
        // waitForExistance(timeout:5)
        
        let avatarsButton = app.navigationBars["_TtGC7SwiftUI32NavigationStackHosting"].buttons["Avatar"]
        XCTAssert(avatarsButton.exists)
    }
    
    fileprivate func checkDetailViewHeaderSection() {
        let detailViewImage = app.images["userImage"]
        let deatilViewUserLabel = app.staticTexts["userLabel"]
        let deatilViewGithubLabel = app.staticTexts["githubGithubLabel"]
        XCTAssert(detailViewImage.exists)
        XCTAssert(deatilViewUserLabel.exists)
        XCTAssert(deatilViewGithubLabel.exists)
    }
    
    fileprivate func checkFirstCellDetailInformation() {
        
        let collectionViewsQuery = app.collectionViews
        
        let detailViewName =  app/*@START_MENU_TOKEN@*/.staticTexts["userLabel"]/*[[".staticTexts[\"mojombo\"]",".staticTexts[\"userLabel\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        let detailViewUrl = app/*@START_MENU_TOKEN@*/.staticTexts["githubGithubLabel"]/*[[".staticTexts[\"Githbb:https:\/\/github.com\/mojombo\"]",".staticTexts[\"githubGithubLabel\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        let detailViewFollowing = collectionViewsQuery/*@START_MENU_TOKEN@*/.staticTexts["Following: 11"]/*[[".cells.staticTexts[\"Following: 11\"]",".staticTexts[\"Following: 11\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        let detailViewRepositories =  collectionViewsQuery/*@START_MENU_TOKEN@*/.staticTexts["Repositories count: 30"]/*[[".cells.staticTexts[\"Repositories count: 30\"]",".staticTexts[\"Repositories count: 30\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        let detailViewFollowers = collectionViewsQuery/*@START_MENU_TOKEN@*/.staticTexts["Followers: 30"]/*[[".cells.staticTexts[\"Followers: 30\"]",".staticTexts[\"Followers: 30\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        let detailViewGists =  collectionViewsQuery/*@START_MENU_TOKEN@*/.staticTexts["Gists count: N/A"]/*[[".cells.staticTexts[\"Gists count: N\/A\"]",".staticTexts[\"Gists count: N\/A\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        
        XCTAssert(detailViewName.exists)
        XCTAssert(detailViewUrl.exists)
        
        //wait for data then test  !!!!!
        if app.staticTexts["Following: 11"].waitForExistence(timeout: 10), app.staticTexts["Followers: 30"].waitForExistence(timeout: 10) {
            
            XCTAssert(detailViewFollowing.exists)
            XCTAssert(detailViewRepositories.exists)
            XCTAssert(detailViewFollowers.exists)
            XCTAssert(detailViewGists.exists)
        }
    }
    
    fileprivate func checkListViewTitle() {
        let avatarsTileText = app.navigationBars["Avatar"].staticTexts["Avatar"]
        XCTAssert(avatarsTileText.exists)
    }
    
    func testTableViewandDetailView() {
        
        app = XCUIApplication()
        app.launch()
        
        checkListViewTitle()
        
        checkTableViewCell()
        
        pickFirstCell()
        
        checkNavigationBarButton()
        
        checkDetailViewHeaderSection()
        
        checkFirstCellDetailInformation()
        
    }
    
    
    
}
