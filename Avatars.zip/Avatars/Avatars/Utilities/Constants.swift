import Foundation

extension String {
    static let githubUsersEndpoint = "https://api.github.com/users"
}

