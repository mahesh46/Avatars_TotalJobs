
import Foundation

struct Repo: Codable {
    let id: Int
    let url: String
    let name: String
}
